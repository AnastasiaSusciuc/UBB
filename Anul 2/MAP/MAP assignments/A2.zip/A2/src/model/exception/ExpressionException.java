package model.exception;

public class ExpressionException extends Exception {
    public ExpressionException(String msg) {
        super(msg);
    }
}
