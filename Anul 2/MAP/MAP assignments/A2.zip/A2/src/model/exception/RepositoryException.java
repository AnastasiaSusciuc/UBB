package model.exception;

public class RepositoryException extends Exception {
    public RepositoryException(String msg) {
        super(msg);
    }
}