package model.exception;

public class StatementException extends Exception {
    public StatementException(String msg) {
        super(msg);
    }
}
