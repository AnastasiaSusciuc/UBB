package model.exception;

public class ADTException extends Exception {
    public ADTException(String msg) {
        super(msg);
    }
}
