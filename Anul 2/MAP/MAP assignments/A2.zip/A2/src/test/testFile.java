package test;

import model.expression.ValueExp;
import model.expression.VarExp;
import model.statement.*;
import model.type.IntType;
import model.type.StringType;
import model.value.IntValue;

import javax.crypto.CipherInputStream;
import java.awt.*;

public class testFile {
    void testFileOperation() {

//        IStmt example_1 = new CompStmt(new VarDeclStmt("varf", new StringType()),
//                new CompStmt(new AssignStmt("varf", new VarExp("test.in")),
//                new CompStmt(new OpenRFileStmt(new VarExp(new String("test.in"))),
//                new CompStmt(new VarDeclStmt("varc", new IntType()),
//                new CompStmt(new ReadFileStmt(new VarExp("varf"), "varc"),
//                new CompStmt(new PrintStmt(new VarExp("varc")),
//                new CompStmt(
//
//                )
//                )
//            )
//        );

//
//        int varc;
//        readFile(varf,varc);print(varc);
//        readFile(varf,varc);print(varc)
//        closeRFile(varf)
    }
}
